// Name       :
// Student ID :

// Complete your code for Question 4 in this file
// Hints: no more than 40 lines


// Change <yourStudentID> for both class and file
public class A1_Q4_yourStudentID {
    public static void main(String[] args) {




    }
}
